<?php
/*
header ("Content-Type: text/html; charset=utf-8");
echo "<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'><!--[if lt IE 9]><meta http-equiv='X-UA-Compatible' content='IE=edge'><![endif]--><style>html{height:100%;font-family:sans-serif;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;font-size:10px;-webkit-tap-highlight-color:transparent}*,:after,:before{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}body{height:100%;margin:0;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:14px;line-height:1.42857143;color:#333;background-color:#fff}button,h3,input{font-family:inherit}h3{font-weight:500;line-height:1.1;color:inherit;margin-top:0;margin-bottom:20px;font-size:24px}.authform{width:300px;background-color:#e1e5ec;padding:25px 27px;margin: 0 auto;-moz-border-radius:4px;-webkit-border-radius:4px;border-radius:4px}</style><title>Добро пожаловать!</title></head><body style='text-align: center'><table style='width:100%;height:100%;border:none'><tbody><tr><td style='padding: 20px'><div class='authform'><h3>Добро пожаловать!</h3><div style='margin-bottom: 18px'>Open Server Panel работает ;-)</div><a href='https://ospanel.io/docs/' id='link' style='color: #4D5662'>Руководство пользователя</a></td></tr></tbody></table></body></html>";
*/

//namespace BestchangeParser;
require_once 'vendor/autoload.php';

use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Cookie\CookieJar;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Cookie\FileCookieJar;

class Client{
	private $http;
	private $cookieJar;
	private $sessionId;


	public function __construct(){	
		$this->http = new GuzzleClient([
			'base_uri' =>  'https://kinogo.by',
			'http_errors' => false,
			//'timeout' => 15,
			//'cookies' => true, 
		]);

		$this->cookieJar = new CookieJar();
		$this->sessionId = "";
	}                           

	public function handshake(string $proxy){
		$this->cookieJar->clear();

		try {
			$response = $this->fetch('/', $proxy);
		} catch (\Exception $e){
			return null;
		}

	 	$statusCode = $response->getStatusCode();
	 	if ($statusCode != 200) {
	 		return null;
	 	}

	 	var_dump($this->cookieJar);
	 	echo '<br><br><br>';
		//$this->sessionId = $this->cookieJar->getCookieByName('PHPSESSID')->getValue();
		$this->cookieJar = new FileCookieJar('cookie_test.json', TRUE);
		//$first = json_decode(file_get_contents('cookie_test.json'), 1);
		//$this->cookieJar = GuzzleHttp\Cookie\CookieJar::fromArray($first, 'kinogo.by');
		var_dump($this->cookieJar);
	 	return true;
	}

	public function getImage(string $proxy) : ?string
	{
		if (!$this->sessionId) {
			return null;
		}
		try {
			
			$response = $this->fetch("", $proxy);
	  } catch (\Exception $e){
	  	return null;
	  }
		if (!$response) {
			return null;
		}
		$statusCode = $response->getStatusCode();
	 	if ($statusCode != 200) {
	 		return null;
	 	}
	 	
	 	return $response->getBody();
	}

	private function fetch(string $url, string $proxy) : Response 
	{
		echo "$url\r\n";
		return $this->http->request('GET', $url, [
			'cookies' => $this->cookieJar,
			'proxy' => $proxy,
			'timeout' => 60
		]);
		
	}
}
echo 'check1';
$clientTest = new Client();
echo 'check2';
$clientTest->handshake('Hb7xHn:AfBew2@213.166.75.107:9024');
$clientTest->getImage('Hb7xHn:AfBew2@213.166.75.107:9024');
echo 'check3';
//echo file_get_contents('test.txt');
