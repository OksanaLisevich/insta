<?php

namespace Instagram\API\Response;

class BulkDeleteCommentsMediaResponse extends BaseResponse {

}