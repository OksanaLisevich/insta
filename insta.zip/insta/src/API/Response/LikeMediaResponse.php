<?php

namespace Instagram\API\Response;

class LikeMediaResponse extends BaseResponse {

}