<?php

namespace Instagram\API\Response\Model;

class Place extends Model {

    /**
     * Title
     * @var string
     */
    protected $title;

    /**
     * Sub Title
     * @var string
     */
    protected $subtitle;

    /**
     * Location
     * @var Location
     */
    protected $location;

    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @param string $title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

    /**
     * @return string
     */
    public function getSubtitle()
    {
        return $this->subtitle;
    }

    /**
     * @param string $subtitle
     */
    public function setSubtitle($subtitle)
    {
        $this->subtitle = $subtitle;
    }

    /**
     * @return Location
     */
    public function getLocation()
    {
        return $this->location;
    }

    /**
     * @param Location $location
     */
    public function setLocation($location)
    {
        $this->location = $location;
    }

}