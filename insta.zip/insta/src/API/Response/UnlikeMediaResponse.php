<?php

namespace Instagram\API\Response;

class UnlikeMediaResponse extends BaseResponse {

}