<?php

namespace Instagram\API\Framework;

use Exception;

class InstagramException extends Exception {

}